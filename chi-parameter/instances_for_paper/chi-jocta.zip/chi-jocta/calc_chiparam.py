import pandas as pd

file = 'dataSP_polymer.csv'
df = pd.read_csv(file, index_col=0)
# qsprtype = "Fedors"
qsprtype = "Krevelen"

names = list(df["name"])
splist_pol = list(df["SP_{}".format(qsprtype)])
# vlist_pol = list(df["Volume"])
npols = len(names)

# file2 = 'dataSP_solvent.csv'
# df2 = pd.read_csv(file2, index_col=0)
# splist_sol = list(df2["SPvalue"])
# names_sol = list(df2["name"])
# nsols = len(names_sol)

R = 8.314 # J/mol/K
V = 100.0 # cm3/mol
chi_s = 0.34

Tlist = [273, 298, 323, 348]

# # polymer - solvent
# icount = 0
# for i in range(npols):
#     for j in range(nsols):
#         for T in Tlist:
#             RT = R*T
#             del_ij = splist_pol[i] - splist_sol[j]
#             #Vr = vlist_pol[i]
#             Vr = V
#             chi_ij = chi_s + Vr / RT * del_ij**2
#             print("{},{},{},{},{:.5f}".format(icount, names[i], names_sol[j], T, chi_ij))
#             icount += 1

# polymer - polymer
print("CID,solute,solvent,T,chi")
icount = 0
for i in range(npols):
    for j in range(i):
        for T in Tlist:
            RT = R*T
            del_ij = splist_pol[i] - splist_pol[j]
            chi_ij = V / RT * del_ij**2
            print("{},{},{},{},{:.5f}".format(icount,names[i], names[j], T, chi_ij))
            icount += 1
            print("{},{},{},{},{:.5f}".format(icount,names[j], names[i], T, chi_ij))
            icount += 1
