import os
import subprocess
from rdkit import Chem
import argparse
import tqdm

class CALC_PS:
    """
    QSPR計算を行うクラス
    """
    # バッチファイルのパス
    BAT_FILE: str = os.path.join("C:\\", "J-OCTA-9.0", "bin", "biceranoQSPR.bat")
    # 終端原子の記号
    TERM: str = 'I'
    # 温度
    K: float = 298.0
    
    def __init__(self, output_dir: str):
        """
        コンストラクタ

        Args:
            output_dir (str): 出力ディレクトリ
        """
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        self.output_dir = output_dir

    def make_command(self, smiles_file: str) -> str:
        """
        コマンドを作成する

        Args:
            smiles_file (str): SMILESファイルのパス

        Returns:
            str: コマンド
        """
        command = f"{self.BAT_FILE} -i {smiles_file} -o {self.output_dir} -term {self.TERM} -k {self.K}"
        return command
    
    def calc(self, smiles_file: str) -> None:
        """
        計算を行う

        Args:
            smiles_file (str): SMILESファイルのパス   
        """
        command = self.make_command(smiles_file)
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        print(result.stdout)
        print(result.stderr)
        return
    
    def sdf_to_smiles(self, sdf_file: str) -> None:
        """
        SDFファイルをSMILLESファイルに変換する
        """
        # smilesディレクトリの作成を確実に
        smiles_dir = os.path.join(self.output_dir, "smiles")
        os.makedirs(smiles_dir, exist_ok=True)

        # SDFファイルの存在確認
        if not os.path.exists(sdf_file):
            print(f"エラー: SDFファイルが見つかりません: {sdf_file}")
            return

        suppl = Chem.SDMolSupplier(sdf_file)
        for i, mol in enumerate(suppl):
            if mol is None:
                continue
            smiles = Chem.MolToSmiles(mol)

            # ファイルベースネームの取得
            mol_name = os.path.splitext(os.path.basename(sdf_file))[0]

            # SMILESファイルのパスを作成
            smiles_file = os.path.join(smiles_dir, f"{mol_name}_{str(i).zfill(2)}.sml")
            
            # ファイルに書き込む
            with open(smiles_file, "w") as f:
                f.write(f"{smiles}\n")
        return
    
    # sdf の 'R' を 'I' に変換する
    def R_to_I(self, sdf_file: str) -> None:
        suppl = Chem.SDMolSupplier(sdf_file)
        for i, mol in enumerate(suppl):
            if mol is None:
                continue
            for atom in mol.GetAtoms():
                if atom.GetSymbol() == 'R':
                    # I は53
                    atom.SetAtomicNum(53)
            w = Chem.SDWriter(sdf_file)
            w.write(mol)
        return
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output_dir", help="出力ディレクトリ")
    parser.add_argument("svg_dir", help="SVGディレクトリ")
    args = parser.parse_args()
    OUTPUT_DIR = args.output_dir
    SVG_DIR = args.svg_dir
    calc_ps = CALC_PS(OUTPUT_DIR)
    
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    
    if not os.path.exists(os.path.join(OUTPUT_DIR, "smiles")):
        os.makedirs(os.path.join(OUTPUT_DIR, "smiles"))
    
    for sdf_file in os.listdir(SVG_DIR):
        if not sdf_file.endswith(".sdf"):
            continue
        calc_ps.R_to_I(os.path.join(SVG_DIR, sdf_file))
        calc_ps.sdf_to_smiles(os.path.join(SVG_DIR, sdf_file))

    for smiles_file in tqdm.tqdm(os.listdir(os.path.join(OUTPUT_DIR, "smiles"))):
        if not smiles_file.endswith(".sml"):
            continue
        calc_ps.calc(os.path.join(OUTPUT_DIR, "smiles", smiles_file))

