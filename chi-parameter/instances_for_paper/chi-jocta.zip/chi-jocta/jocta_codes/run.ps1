# フォルダの設定
$svg_folder = "svg_1206"
$ps_folder = "ps_1206"
# Excelファイルのパス
$excel_path = "ps_1206.xlsx"

# Pythonの実行ファイルのパス
$python_exe = "C:\Users\mao_takekida\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.12_qbz5n2kfra8p0\python.exe"

# calc_ps.py を実行
& $python_exe "calc_ps.py" $ps_folder $svg_folder

# make_excel.py を実行
& $python_exe "make_excel.py" $excel_path $ps_folder
