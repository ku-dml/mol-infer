import openpyxl
import os
import pandas as pd
import argparse


class MakeExcelFile:
    def __init__(self: object, output_dir: str) -> None:
        self.output_dir = output_dir
    
    # (Fedors, Krevelen)の値を取得
    def get_ps_value(self: object, path_to_ps_file: str) -> tuple[float, float]:
        """PSの値を取得

        Args:
            path_to_ps_file (str): PSファイルのパス

        Returns:
            tuple[float, float]: Fedors, Krevelen
        """
        
        try:
            with open(path_to_ps_file, "r") as f:
                lines = f.readlines()
            # 25, 26行目にpsの値がある
            fedors = float(lines[24].split("\t")[3])
            krevelen = float(lines[25].split("\t")[3])
        except Exception as e:
            print(f"PSファイルの読み込みに失敗しました: {path_to_ps_file}")
            print(e)
            raise e

        return fedors, krevelen
    
    def make_excel_file(self, excel_path: str, ps_values: list[tuple[str, float, float]]) -> None:
        """ExcelファイルにPSの値を書き込む

        Args:
            excel_path (str): Excelファイルのパス
            ps_values (list[tuple[str, float, float]]): PSの値 (分子名, Fedors, Krevelen)
        """
        # ファイルが存在しない場合は作成
        if not os.path.exists(excel_path):
            wb = openpyxl.Workbook()
            ws = wb.active
        else:
            wb = openpyxl.load_workbook(excel_path)
            ws = wb.active
            
        # ヘッダーを書き込む
        ws.cell(row=1, column=1, value="分子名")
        ws.cell(row=1, column=2, value="Fedors")
        ws.cell(row=1, column=3, value="Krevelen")
        
        # 行を取得
        row = 2
        
        for mol_name, fedors, krevelen in ps_values:
            # (分子名, Fedors, Krevelen)
            # 有効数字は4桁
            ws.cell(row=row, column=1, value=mol_name)
            ws.cell(row=row, column=2, value=f"{fedors:.4f}")
            ws.cell(row=row, column=3, value=f"{krevelen:.4f}")
            row += 1
        
        wb.save(excel_path)
        wb.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("excel_path", help="Excelファイルのパス")
    parser.add_argument("ps_dir", help="PS_ooのディレクトリ")
    args = parser.parse_args()

    mef = MakeExcelFile(args.ps_dir)
    ps_values = []
    for file in os.listdir(os.path.join(mef.output_dir, "smiles")):
        if not file.endswith(".sml"):
            continue
        mol_name = file.split(".sml")[0]
        path_to_ps_file = os.path.join(mef.output_dir, f"{mol_name}_001_000.298.0.K.qspr")
        
        fedors, krevelen = mef.get_ps_value(path_to_ps_file)
        ps_values.append((mol_name, fedors, krevelen))
    
    mef.make_excel_file(args.excel_path, ps_values)
    
    