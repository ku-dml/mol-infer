The file "data_Chi_Aoki_SMILES.csv" is the original data obtained from the paper.
generate_raw_sdf_Aoki_Chi.py is used to generate the files Chi_Aoki_ch1_R.sdf and Chi_Aoki_ch2_R.sdf.
Then use the "polymer_converter_sdf_to_sdf.py" to generate Chi_Aoki_ch1_e.sdf and Chi_Aoki_ch2_e.sdf, and use "contract_e.cpp" to generate Chi_Aoki_ch1.sdf and Chi_Aoki_ch2.sdf.