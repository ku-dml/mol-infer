The file "data_Chi_Nistane_SMILES.csv" is the original data obtained from the paper.
generate_raw_sdf_Nistane_Chi.py is used to generate the files Chi_Nistane_ch1_R.sdf and Chi_Nistane_ch2_R.sdf.
Then use the "polymer_converter_sdf_to_sdf.py" to generate Chi_Nistane_ch1_e.sdf and Chi_Nistane_ch2_e.sdf, and use "contract_e.cpp" to generate Chi_Nistane_ch1.sdf and Chi_Nistane_ch2.sdf.