import rdkit
from rdkit import Chem
import pubchempy as pcp
import pandas as pd
import numpy as np

csv_filename = "./data_Chi_Nistane.csv"

csv_data = pd.read_csv(csv_filename)

print(csv_data.columns)
print(csv_data.index)

mols_1 = []
mols_2 = []
names = []
values = []

for (i, cid) in enumerate(csv_data.index):
    # ch_smiles = csv_data.at[cid, 'ps_pair_nonCyclic'].split('_')

    Ch1_smiles = csv_data.at[cid, 'Polymer_SMILES']
    Ch2_smiles = csv_data.at[cid, 'Solvent_SMILES']

    Chi_value = csv_data.at[cid, 'chi']
    T = csv_data.at[cid, 'temperature']

    if "C[*]C" in Ch1_smiles:
        continue

    mols_1.append(Chem.MolFromSmiles(Ch1_smiles))
    mols_2.append(Chem.MolFromSmiles(Ch2_smiles))
    names.append(f"{i}_{T}")
    values.append(Chi_value)

writer = Chem.SDWriter("./raw_data_sdf/Chi_Nistane_ch1_R.sdf")

for (mol, name) in zip(mols_1, names):
    mol_tmp = Chem.AddHs(mol)
    mol_tmp.SetProp("_Name", name)
    writer.write(mol_tmp)

writer.close()

writer = Chem.SDWriter("./raw_data_sdf/Chi_Nistane_ch2_R.sdf")

for (mol, name) in zip(mols_2, names):
    mol_tmp = Chem.AddHs(mol)
    mol_tmp.SetProp("_Name", name)
    writer.write(mol_tmp)

writer.close()

value_filename = "./raw_data_sdf/Chi_Nistane_values.txt"

with open(value_filename, 'w') as f:
    f.write("CID,a\n")
    for (name, chi) in zip(names, values):
        f.write(f"{name},{chi}\n")
