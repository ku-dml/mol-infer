#!/bin/bash


echo 'Dataset	property	n_	K_	K_linear	K_quad	Way	R2_train	R2_test 	Time'


python SINGLE_eval.py   ./data_copolymer/reis_random_fv_filtered_desc_norm.csv                    ./data_copolymer/reis_19F_NMR_filtered_values.txt             -l 0 -m R2  
python SINGLE_eval.py   ./data_copolymer/reis_random_fv_filtered_desc_norm.csv                    ./data_copolymer/reis_19F_NMR_filtered_values.txt             -ann ./log/LLR_ANN_reis_random_fv_filtered_reis_19F_NMR_filtered_desc_norm.csv 0.83 1007 17 12  -m R2    
python SINGLE_eval.py   ./data_copolymer/reis_random_fv_filtered_desc_norm.csv                    ./data_copolymer/reis_19F_NMR_filtered_values.txt             -rf ./log/RF_reis_random_fv_filtered_reis_19F_NMR_filtered_desc_norm.csv max_features 3 min_samples_split 5 min_samples_leaf 2 max_depth None n_estimators 75  -m R2   
python SINGLE_eval.py   ./data_copolymer/reis_random_fv_filtered_reis_19F_NMR_filtered_quadratic_h5000_desc_norm.csv                    ./data_copolymer/reis_19F_NMR_filtered_values.txt             -rbsp ./log/MLR_based_BSP_reis_random_fv_filtered_reis_19F_NMR_filtered_quadratic_h5000_reis_19F_NMR_filtered_desc_norm.csv -m R2   


python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_EA_vs_SHE_eV_values.txt             -l 8.200000000000001e-06 -m R2  
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_EA_vs_SHE_eV_values.txt             -ann ./log/LLR_ANN_Bai_A_B_alternate_Bai_EA_vs_SHE_eV_desc_norm.csv 0.98 941 74 74 74 74 74  -m R2    
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_EA_vs_SHE_eV_values.txt             -rf ./log/RF_Bai_A_B_alternate_Bai_EA_vs_SHE_eV_desc_norm.csv max_features 1.0 min_samples_split 3 min_samples_leaf 1 max_depth None n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_Bai_EA_vs_SHE_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/Bai_EA_vs_SHE_eV_values.txt             -rbsp ./log/MLR_based_BSP_Bai_A_B_alternate_Bai_EA_vs_SHE_eV_quadratic_h5000_Bai_EA_vs_SHE_eV_desc_norm.csv -m R2   


python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_IP_vs_SHE_eV_values.txt             -l 7.3e-06 -m R2  
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_IP_vs_SHE_eV_values.txt             -ann ./log/LLR_ANN_Bai_A_B_alternate_Bai_IP_vs_SHE_eV_desc_norm.csv 0.98 6681 81  -m R2    
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_IP_vs_SHE_eV_values.txt             -rf ./log/RF_Bai_A_B_alternate_Bai_IP_vs_SHE_eV_desc_norm.csv max_features 1.0 min_samples_split 2 min_samples_leaf 1 max_depth None n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_Bai_IP_vs_SHE_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/Bai_IP_vs_SHE_eV_values.txt             -rbsp ./log/MLR_based_BSP_Bai_A_B_alternate_Bai_IP_vs_SHE_eV_quadratic_h5000_Bai_IP_vs_SHE_eV_desc_norm.csv -m R2   

python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_Optical_Gap_eV_values.txt             -l 0 -m R2  
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_Optical_Gap_eV_values.txt             -ann ./log/LLR_ANN_Bai_A_B_alternate_Bai_Optical_Gap_eV_desc_norm.csv 0.94 1156 80 80 80  -m R2    
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_Optical_Gap_eV_values.txt             -rf ./log/RF_Bai_A_B_alternate_Bai_Optical_Gap_eV_desc_norm.csv max_features 1.0 min_samples_split 10 min_samples_leaf 1 max_depth None n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_Bai_Optical_Gap_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/Bai_Optical_Gap_eV_values.txt             -rbsp ./log/MLR_based_BSP_Bai_A_B_alternate_Bai_Optical_Gap_eV_quadratic_h5000_Bai_Optical_Gap_eV_desc_norm.csv -m R2  

python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_Oscillator_Strength_au_values.txt             -l 2.8000000000000003e-05 -m R2  
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_Oscillator_Strength_au_values.txt             -ann ./log/LLR_ANN_Bai_A_B_alternate_Bai_Oscillator_Strength_au_desc_norm.csv 0.69 57 66 49 36 27  -m R2    
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_desc_norm.csv                    ./data_copolymer/Bai_Oscillator_Strength_au_values.txt             -rf ./log/RF_Bai_A_B_alternate_Bai_Oscillator_Strength_au_desc_norm.csv max_features 1.0 min_samples_split 3 min_samples_leaf 1 max_depth 15 n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/Bai_A_B_alternate_Bai_Oscillator_Strength_au_quadratic_h5000_desc_norm.csv                    ./data_copolymer/Bai_Oscillator_Strength_au_values.txt             -rbsp ./log/MLR_based_BSP_Bai_A_B_alternate_Bai_Oscillator_Strength_au_quadratic_h5000_Bai_Oscillator_Strength_au_desc_norm.csv -m R2   

python SINGLE_eval.py   ./data_copolymer/brierly-croft_random_binary_desc_norm.csv                    ./data_copolymer/brierly-croft_Tg_values.txt             -l 0.0001 -m R2 
python SINGLE_eval.py   ./data_copolymer/brierly-croft_random_binary_desc_norm.csv                    ./data_copolymer/brierly-croft_Tg_values.txt             -ann ./log/LLR_ANN_brierly-croft_random_binary_brierly-croft_Tg_desc_norm.csv 0.87 1014 12 9 6  -m R2   
python SINGLE_eval.py   ./data_copolymer/brierly-croft_random_binary_desc_norm.csv                    ./data_copolymer/brierly-croft_Tg_values.txt             -rf ./log/RF_brierly-croft_random_binary_brierly-croft_Tg_desc_norm.csv max_features 10 min_samples_split 2 min_samples_leaf 1 max_depth 15 n_estimators 50  -m R2  
python SINGLE_eval.py   ./data_copolymer/brierly-croft_random_binary_brierly-croft_Tg_quadratic_h5000_desc_norm.csv                    ./data_copolymer/brierly-croft_Tg_values.txt             -rbsp ./log/MLR_based_BSP_brierly-croft_random_binary_brierly-croft_Tg_quadratic_h5000_brierly-croft_Tg_desc_norm.csv -m R2   

python SINGLE_eval.py   ./data_copolymer/jain_random_binary_remove_nan_desc_norm.csv                    ./data_copolymer/jain_log_melt_viscosity_values.txt             -l 2.8000000000000003e-05 -m R2  
python SINGLE_eval.py   ./data_copolymer/jain_random_binary_remove_nan_desc_norm.csv                    ./data_copolymer/jain_log_melt_viscosity_values.txt             -ann ./log/LLR_ANN_jain_random_binary_remove_nan_jain_log_melt_viscosity_desc_norm.csv 0.98 8565 54 54 54 54  -m R2    
python SINGLE_eval.py   ./data_copolymer/jain_random_binary_remove_nan_desc_norm.csv                    ./data_copolymer/jain_log_melt_viscosity_values.txt             -rf ./log/RF_jain_random_binary_remove_nan_jain_log_melt_viscosity_desc_norm.csv max_features 10 min_samples_split 2 min_samples_leaf 1 max_depth 20 n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/jain_random_binary_remove_nan_jain_log_melt_viscosity_quadratic_h5000_desc_norm.csv                    ./data_copolymer/jain_log_melt_viscosity_values.txt             -rbsp ./log/MLR_based_BSP_jain_random_binary_remove_nan_jain_log_melt_viscosity_quadratic_h5000_jain_log_melt_viscosity_desc_norm.csv -m R2   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_EA_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_EA_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_EA_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_wilbraham_5000_Calib_EA_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_EA_eV_values.txt             -rbsp   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_Excitation_Energy_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_Excitation_Energy_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_Excitation_Energy_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_wilbraham_5000_Calib_Excitation_Energy_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_Excitation_Energy_eV_values.txt             -rbsp   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_IP_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_IP_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_IP_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_wilbraham_5000_Calib_IP_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Calib_IP_eV_values.txt             -rbsp   

python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_eV_values.txt             -l 0 -m R2 
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_eV_values.txt             -ann ./log/LLR_ANN_wilbraham_5000_alternate_wilbraham_5000_EA_eV_desc_norm.csv 0.98 2686 63 63 63 63  -m R2   
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_eV_values.txt             -rf ./log/RF_wilbraham_5000_alternate_wilbraham_5000_EA_eV_desc_norm.csv max_features 1.0 min_samples_split 2 min_samples_leaf 1 max_depth None n_estimators 100  -m R2  
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_wilbraham_5000_EA_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_eV_values.txt             -rbsp ./log/MLR_based_BSP_wilbraham_5000_alternate_wilbraham_5000_EA_eV_quadratic_h5000_wilbraham_5000_EA_eV_desc_norm.csv -m R2   

python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Excitation_Energy_eV_values.txt             -l 1e-05 -m R2  
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Excitation_Energy_eV_values.txt             -ann ./log/LLR_ANN_wilbraham_5000_alternate_wilbraham_5000_Excitation_Energy_eV_desc_norm.csv 0.96 9734 60 60 60 60  -m R2    
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Excitation_Energy_eV_values.txt             -rf ./log/RF_wilbraham_5000_alternate_wilbraham_5000_Excitation_Energy_eV_desc_norm.csv max_features 1.0 min_samples_split 2 min_samples_leaf 1 max_depth None n_estimators 75  -m R2   
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_wilbraham_5000_Excitation_Energy_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_Excitation_Energy_eV_values.txt             -rbsp ./log/MLR_based_BSP_wilbraham_5000_alternate_wilbraham_5000_Excitation_Energy_eV_quadratic_h5000_wilbraham_5000_Excitation_Energy_eV_desc_norm.csv -m R2   

python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_eV_values.txt             -l 0 -m R2  
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_eV_values.txt             -ann ./log/LLR_ANN_wilbraham_5000_alternate_wilbraham_5000_IP_eV_desc_norm.csv 0.98 3523 57 57 57 57  -m R2    
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_eV_values.txt             -rf ./log/RF_wilbraham_5000_alternate_wilbraham_5000_IP_eV_desc_norm.csv max_features 1.0 min_samples_split 3 min_samples_leaf 1 max_depth None n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_wilbraham_5000_IP_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_eV_values.txt             -rbsp ./log/MLR_based_BSP_wilbraham_5000_alternate_wilbraham_5000_IP_eV_quadratic_h5000_wilbraham_5000_IP_eV_desc_norm.csv -m R2   


# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_EA_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_EA_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_EA_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_wilbraham_all_Calib_EA_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_EA_eV_values.txt             -rbsp   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_Excitation_Energy_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_Excitation_Energy_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_Excitation_Energy_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_wilbraham_all_Calib_Excitation_Energy_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_Excitation_Energy_eV_values.txt             -rbsp   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_IP_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_IP_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_IP_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_wilbraham_all_Calib_IP_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_all_Calib_IP_eV_values.txt             -rbsp   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_EA_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_EA_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_EA_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_wilbraham_all_EA_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_all_EA_eV_values.txt             -rbsp   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Excitation_Energy_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Excitation_Energy_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_Excitation_Energy_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_wilbraham_all_Excitation_Energy_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_all_Excitation_Energy_eV_values.txt             -rbsp   

# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_IP_eV_values.txt             -l    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_IP_eV_values.txt             -ann    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_desc_norm.csv                    ./data_copolymer/wilbraham_all_IP_eV_values.txt             -rf    
# python SINGLE_eval.py   ./data_copolymer/wilbraham_all_alternate_wilbraham_all_IP_eV_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_all_IP_eV_values.txt             -rbsp   

python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_recalc_values.txt             -l 2.8000000000000003e-05 -m R2  
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_recalc_values.txt             -ann ./log/LLR_ANN_wilbraham_5000_alternate_recalc_wilbraham_5000_EA_recalc_desc_norm.csv 0.68 31 52 39 29  -m R2    
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_recalc_values.txt             -rf ./log/RF_wilbraham_5000_alternate_recalc_wilbraham_5000_EA_recalc_desc_norm.csv max_features 1.0 min_samples_split 3 min_samples_leaf 2 max_depth 20 n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_wilbraham_5000_EA_recalc_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_EA_recalc_values.txt             -rbsp ./log/MLR_based_BSP_wilbraham_5000_alternate_recalc_wilbraham_5000_EA_recalc_quadratic_h5000_wilbraham_5000_EA_recalc_desc_norm.csv -m R2   

python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_recalc_values.txt             -l 1.9e-06 -m R2  
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_recalc_values.txt             -ann ./log/LLR_ANN_wilbraham_5000_alternate_recalc_wilbraham_5000_IP_recalc_desc_norm.csv 0.75 171 58 58 58  -m R2    
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_recalc_values.txt             -rf ./log/RF_wilbraham_5000_alternate_recalc_wilbraham_5000_IP_recalc_desc_norm.csv max_features sqrt min_samples_split 3 min_samples_leaf 1 max_depth 20 n_estimators 100  -m R2   
python SINGLE_eval.py   ./data_copolymer/wilbraham_5000_alternate_recalc_wilbraham_5000_IP_recalc_quadratic_h5000_desc_norm.csv                    ./data_copolymer/wilbraham_5000_IP_recalc_values.txt             -rbsp ./log/MLR_based_BSP_wilbraham_5000_alternate_recalc_wilbraham_5000_IP_recalc_quadratic_h5000_wilbraham_5000_IP_recalc_desc_norm.csv -m R2   





