
import os

infer_name = "infer_2LMM_polymer.py"

prop_1 = "./MILP_result/AmpD/AmpD"
prop_2 = "./MILP_result/HcLiq/HcLiq"
prop_3 = "./MILP_result/Tg/Tg"
prop_n_1 = "AmpD"
prop_n_2 = "HcLiq"
prop_n_3 = "Tg"

# tv_list = [("0.1", "1000", "0.1", "1000", "0.1", "1000"),]

tv_list = [("1.200", "1.224", "624.0", "628.0", "171.9", "174.0"),]

abbr_list = ["P1",]

for (tv_lb1, tv_ub1, tv_lb2, tv_ub2, tv_lb3, tv_ub3), instance_name_abbr in zip(tv_list, abbr_list):
    instance_name = f"instance_{instance_name_abbr}_polymer.txt"
    fringe_name = f"ins_{instance_name_abbr}_fringe_polymer.txt"

    os.system(f"python {infer_name} {prop_1} {prop_2} {prop_3} {tv_lb1} {tv_ub1} {tv_lb2} {tv_ub2} {tv_lb3} {tv_ub3} {instance_name} {fringe_name} ./MILP_result/sdf/{prop_n_1}_{prop_n_2}_{prop_n_3}_{instance_name_abbr}_{tv_lb1}_{tv_ub1}_{tv_lb2}_{tv_ub2}_{tv_lb3}_{tv_ub3} > ./MILP_result/stdout/stdout_{prop_n_1}_{prop_n_2}_{prop_n_3}_{instance_name_abbr}_{tv_lb1}_{tv_ub1}_{tv_lb2}_{tv_ub2}_{tv_lb3}_{tv_ub3}.txt")


