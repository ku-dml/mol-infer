import os

infer_name = "infer_2LMM_polymer.py"

prop_1 = "./MILP_result/HcSol/HcSol"
prop_2 = "./MILP_result/MolV/MolV"
prop_3 = "./MILP_result/RefIdx/RefIdx"
prop_n_1 = "HcSol"
prop_n_2 = "MolV"
prop_n_3 = "RefIdx"

# tv_list = [("84.5", "720.5", "60.7", "466.6", "1.339", "1.683"),]

tv_list = [("657", "659", "463", "465", "1.339", "1.359"),]

abbr_list = ["P2",]

for (tv_lb1, tv_ub1, tv_lb2, tv_ub2, tv_lb3, tv_ub3), instance_name_abbr in zip(tv_list, abbr_list):
    instance_name = f"instance_{instance_name_abbr}_polymer.txt"
    fringe_name = f"ins_{instance_name_abbr}_fringe_polymer.txt"

    os.system(f"python {infer_name} {prop_1} {prop_2} {prop_3} {tv_lb1} {tv_ub1} {tv_lb2} {tv_ub2} {tv_lb3} {tv_ub3} {instance_name} {fringe_name} ./MILP_result/sdf/{prop_n_1}_{prop_n_2}_{prop_n_3}_{instance_name_abbr}_{tv_lb1}_{tv_ub1}_{tv_lb2}_{tv_ub2}_{tv_lb3}_{tv_ub3} > ./MILP_result/stdout/stdout_{prop_n_1}_{prop_n_2}_{prop_n_3}_{instance_name_abbr}_{tv_lb1}_{tv_ub1}_{tv_lb2}_{tv_ub2}_{tv_lb3}_{tv_ub3}.txt")


