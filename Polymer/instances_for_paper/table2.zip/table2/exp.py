
import os

os.system(f"python exp_AmpD.py")
os.system(f"python exp_HcLiq.py")
os.system(f"python exp_Perm.py")
os.system(f"python exp_RefIdx.py")
os.system(f"python exp_Tg.py")

