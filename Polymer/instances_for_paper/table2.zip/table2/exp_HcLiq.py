
import os

infer_name = "infer_2LMM_polymer.py"

prop = "./MILP_result/HcLiq/HcLiq"
prop_n = "HcLiq"

# tv_list = [("105.7", "678.1"), ("105.7", "678.1")]
# abbr_list = ["a", "b"]

tv_list = [("105.7", "678.1"), ("658.8", "660.2")]
abbr_list = ["a", "b"]

# tv_list = [("569.0", "570.5"), ("601.6", "603.2"), ("658.8", "660.2")]
# abbr_list = ["b", "b", "b"]


for (tv_lb, tv_ub), instance_name_abbr in zip(tv_list, abbr_list):
    instance_name = f"./MILP_result/{prop_n}/instance_{instance_name_abbr}_polymer.txt"
    fringe_name = f"./MILP_result/{prop_n}/ins_{instance_name_abbr}_fringe_2LMM.txt"

    os.system(f"python {infer_name} {prop} {tv_lb} {tv_ub} {instance_name} {fringe_name} ./MILP_result/sdf/{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub} > ./MILP_result/stdout/stdout_{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub}.txt")


