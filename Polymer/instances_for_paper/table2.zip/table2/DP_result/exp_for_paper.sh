#!/bin/sh



./generate_isomers.o ../instances/AmpD_a_0.885_0.890.sdf 10 1000000 0 300 1000000 100 Results_AmpD_a_0.885_0.890.sdf ../instances/AmpD_a_0.885_0.890_partition.txt ../../MILP/MILP_result/AmpD/ins_a_fringe_2LMM.txt  
./generate_isomers.o ../instances/AmpD_b_1.344_1.350.sdf 10 1000000 0 300 1000000 100 Results_AmpD_b_1.344_1.350.sdf ../instances/AmpD_b_1.344_1.350_partition.txt ../../MILP/MILP_result/AmpD/ins_b_fringe_2LMM.txt  

./generate_isomers.o ../instances/HcLiq_b_658.8_660.2.sdf 10 1000000 0 300 1000000 100 Results_HcLiq_b_658.8_660.2.sdf ../instances/HcLiq_b_658.8_660.2_partition.txt ../../MILP/MILP_result/HcLiq/ins_b_fringe_2LMM.txt  
./generate_isomers.o ../instances/Perm_a_4.128_4.150.sdf 10 1000000 0 300 1000000 100 Results_Perm_a_4.128_4.150.sdf ../instances/Perm_a_4.128_4.150_partition.txt ../../MILP/MILP_result/Perm/ins_a_fringe_2LMM.txt  
./generate_isomers.o ../instances/Perm_b_3.158_3.188.sdf 10 1000000 0 300 1000000 100 Results_Perm_b_3.158_3.188.sdf ../instances/Perm_b_3.158_3.188_partition.txt ../../MILP/MILP_result/Perm/ins_b_fringe_2LMM.txt  
./generate_isomers.o ../instances/RefIdx_a_1.339_1.355.sdf 10 1000000 0 300 1000000 100 Results_RefIdx_a_1.339_1.355.sdf ../instances/RefIdx_a_1.339_1.355_partition.txt ../../MILP/MILP_result/RefIdx/ins_a_fringe_2LMM.txt  
./generate_isomers.o ../instances/RefIdx_b_1.406_1.422.sdf 10 1000000 0 300 1000000 100 Results_RefIdx_b_1.406_1.422.sdf ../instances/RefIdx_b_1.406_1.422_partition.txt ../../MILP/MILP_result/RefIdx/ins_b_fringe_2LMM.txt  
./generate_isomers.o ../instances/Tg_a_180.0_181.6.sdf 10 1000000 0 300 1000000 100 Results_Tg_a_180.0_181.6.sdf ../instances/Tg_a_180.0_181.6_partition.txt ../../MILP/MILP_result/Tg/ins_a_fringe_2LMM.txt  
./generate_isomers.o ../instances/Tg_b_180.6_182.8.sdf 10 1000000 0 300 1000000 100 Results_Tg_b_180.6_182.8.sdf ../instances/Tg_b_180.6_182.8_partition.txt ../../MILP/MILP_result/Tg/ins_b_fringe_2LMM.txt  
