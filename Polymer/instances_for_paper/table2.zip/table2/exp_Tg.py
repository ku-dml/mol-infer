
import os

infer_name = "infer_2LMM_polymer.py"

prop = "./MILP_result/Tg/Tg"
prop_n = "Tg"

# tv_list = [("171", "673"), ("171", "673")]
# abbr_list = ["a", "b"]

tv_list = [("180.0", "181.6"), ("180.6", "182.8")]
abbr_list = ["a", "b"]

# tv_list = [("182.4", "183.6"), ("175.2", "176.2"), ("180.0", "181.6"), ("183.8", "184.2"), ("140.8", "142.0"), ("180.6", "182.8")]
# abbr_list = ["a", "a", "a", "b", "b", "b"]

for (tv_lb, tv_ub), instance_name_abbr in zip(tv_list, abbr_list):
    instance_name = f"./MILP_result/{prop_n}/instance_{instance_name_abbr}_polymer.txt"
    fringe_name = f"./MILP_result/{prop_n}/ins_{instance_name_abbr}_fringe_2LMM.txt"

    os.system(f"python {infer_name} {prop} {tv_lb} {tv_ub} {instance_name} {fringe_name} ./MILP_result/sdf/{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub} > ./MILP_result/stdout/stdout_{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub}.txt")


