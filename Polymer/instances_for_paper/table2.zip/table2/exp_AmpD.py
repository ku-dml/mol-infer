
import os

infer_name = "infer_2LMM_polymer.py"

prop = "./MILP_result/AmpD/AmpD"
prop_n = "AmpD"

# tv_list = [("0.838", "1.45"), ("0.838", "1.45")]
# abbr_list = ["a", "b"]

tv_list = [("0.885", "0.890"), ("1.344", "1.350")]
abbr_list = ["a", "b"]


# tv_list = [("0.874", "0.884"), ("0.872", "0.880"), ("0.884", "0.892"), ("0.888", "0.896"), ("0.878", "0.886"), ("0.886", "0.896")]
# abbr_list = ["a", "a", "a", "a", "a", "a"]


for (tv_lb, tv_ub), instance_name_abbr in zip(tv_list, abbr_list):
    instance_name = f"./MILP_result/{prop_n}/instance_{instance_name_abbr}_polymer.txt"
    fringe_name = f"./MILP_result/{prop_n}/ins_{instance_name_abbr}_fringe_2LMM.txt"

    os.system(f"python {infer_name} {prop} {tv_lb} {tv_ub} {instance_name} {fringe_name} ./MILP_result/sdf/{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub} > ./MILP_result/stdout/stdout_{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub}.txt")


