
import os

infer_name = "infer_2LMM_polymer.py"

prop = "./MILP_result/Perm/Perm"
prop_n = "Perm"

V_lb = 60.0
V_ub = 10000000.0

# tv_list = [("2.23", "4.91"), ("2.23", "4.91")]
# abbr_list = ["a", "b"]

tv_list = [("4.128", "4.150"), ("3.158", "3.188")]
abbr_list = ["a", "b"]

# tv_list = [("3.95", "4.02"), ("2.68", "2.72"), ("4.128", "4.150"), ("3.172", "3.188"), ("2.828", "2.858"), ("3.480", "3.518")]
# abbr_list = ["a", "a", "a", "b", "b", "b"]

# tv_list = [("3.158", "3.188"),]
# abbr_list = ["b",]

for (tv_lb, tv_ub), instance_name_abbr in zip(tv_list, abbr_list):
    instance_name = f"./MILP_result/{prop_n}/instance_{instance_name_abbr}_polymer.txt"
    fringe_name = f"./MILP_result/{prop_n}/ins_{instance_name_abbr}_fringe_2LMM.txt"

    os.system(f"python {infer_name} {prop} {tv_lb} {tv_ub} {instance_name} {fringe_name} ./MILP_result/sdf/{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub} {V_lb} {V_ub} > ./MILP_result/stdout/stdout_{prop_n}_{instance_name_abbr}_{tv_lb}_{tv_ub}.txt")


